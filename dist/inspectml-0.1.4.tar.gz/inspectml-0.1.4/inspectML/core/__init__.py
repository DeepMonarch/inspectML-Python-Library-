"""
InspectML Core
--------------
Core internal functions or foundational classes (coming soon).
"""
